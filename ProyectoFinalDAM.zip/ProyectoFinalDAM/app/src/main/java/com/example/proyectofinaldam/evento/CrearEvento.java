package com.example.proyectofinaldam.evento;

import android.app.Dialog;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import com.example.layoutsproyectof.R;

import java.util.Calendar;

public class CrearEvento extends DialogFragment {
    private TextView tv_nombreEvento;
    private EditText et_nombreEvento;
    private TextView tv_fechaEvento;
    private EditText et_fechaEvento;
    private TextView tv_grupoEvento;
    private Spinner sp_grupoEvento;
    private TextView tv_descripcionEvento;
    private EditText et_descripcionEvento;
    private Button btn_crearEvento;



    public CrearEvento(){
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        //View view = inflater.inflate(R.layout.crear_evento, container, false);
        View view = inflater.inflate(R.layout.crear_evento, container, false);

        et_nombreEvento = view.findViewById(R.id.et_nombre_eventoCrearE);
        et_fechaEvento = view.findViewById(R.id.et_fechaCrearE);
        sp_grupoEvento = view.findViewById(R.id.sp_grupoCrearE);
        et_descripcionEvento = view.findViewById(R.id.et_descripcionCrearE);
        btn_crearEvento = view.findViewById(R.id.btn_crear_evento);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, new String[]{"Opción 1", "Opción 2", "Opción 3"});
        sp_grupoEvento.setAdapter(adapter);

        btn_crearEvento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //GUARDAR LOS DATOS.
                Toast.makeText(getContext(), "hola funciona", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

}








