package com.example.proyectofinaldam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.layoutsproyectof.R;
import com.example.proyectofinaldam.InicioSesion.Login;

/*public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        Intent irLogin = new Intent(MainActivity.this, Login.class);
        startActivity(irLogin);

    }
}*/