package com.example.proyectofinaldam.InicioSesion;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.layoutsproyectof.R;
import com.example.proyectofinaldam.evento.CrearEvento;


public class Login extends AppCompatActivity {
    private EditText etUsuario;
    private EditText etPassword;
    private Button btnLogin;
    private Button btnRecupContraseña;
    private TextView  tvLogin;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        tvLogin = findViewById(R.id.tv_login);
        etUsuario = findViewById(R.id.et_usuario);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        btnRecupContraseña = findViewById(R.id.btn_recuperar_password);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // CODIGO INICIO SESION SI ESO CORRECTO:
                    ventanaMostrarCrearE(v);

            }
        });
        btnRecupContraseña.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent irRecuperarPassw = new Intent(Login.this , RecuperarPassword.class);
                startActivity(irRecuperarPassw);
            }
        });
    }
    public void ventanaMostrarCrearE(View v){

        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        CrearEvento crearEvento = new CrearEvento();

        // obtener las dimensiones de la pantalla
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int screenWidth = metrics.widthPixels;
        int screenHeight = metrics.heightPixels;

        // calcular los valores correspondientes al % del ancho y alto de la pantalla
        int dialogWidth = (int) (screenWidth * 0.9);
        int dialogHeight = (int) (screenHeight * 0.9);

        // crear un objeto Dialog y establecer el estilo personalizado y las dimensiones
        Dialog dialog = new Dialog(this, R.style.VentanaDialogRecuperar);
        dialog.setContentView(R.layout.crear_evento);
        Window window = dialog.getWindow();
        window.setLayout(dialogWidth, dialogHeight);

        // mostrar el diálogo en lugar del fragment

        crearEvento.show(transaction, "CrearEvento");

    }
}
