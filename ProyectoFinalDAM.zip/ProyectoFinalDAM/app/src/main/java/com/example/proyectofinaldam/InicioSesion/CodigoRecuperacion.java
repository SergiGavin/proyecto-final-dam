package com.example.proyectofinaldam.InicioSesion;


import static android.os.Build.VERSION_CODES.R;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;


public class CodigoRecuperacion extends DialogFragment {
    private EditText et_codigoRecuperacion;
    private Button btn_codigoRecuperacion;
    private TextView tv_codigoRecuperacion;
    private Button btn_cancelarRecuperacion;


    public CodigoRecuperacion() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {



        //View view = inflater.inflate(R.layout.codigo_recuperar, container, false);
        View view = inflater.inflate();


        btn_codigoRecuperacion = view.findViewById(R.id.btn_codigoRecuperacion);
        btn_cancelarRecuperacion = view.findViewById(R.id.btn_cancelar);
        btn_codigoRecuperacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //VERIFICAMOS SI EL CODIGO ES CORRECTO
                Toast.makeText(getContext(), "hola funciona", Toast.LENGTH_SHORT).show();
                //Se cierra cuando se verifique el codigo
                dismiss();


            }
        });
        btn_cancelarRecuperacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });


        return view;
    }
}