package com.example.proyectofinaldam;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.layoutsproyectof.R;

public class PantallaPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pantalla_principal);

        Button btnIzquierda = findViewById(R.id.btnIzquierda);


        btnIzquierda.setOnClickListener(v -> {
            setContentView(R.layout.desplegable_grupo);
        });

        Button btnEvento = findViewById(R.id.btnEvento);

        btnEvento.setOnClickListener(view -> {
            setContentView(R.layout.crear_evento);
        });
    }




}